package com.bank.user.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.List;
import java.util.Set;

import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.bank.user.dto.ServiceUserResponse;
import com.bank.user.dto.UserRequest;
import com.bank.user.dto.UserRequestDto;
import com.bank.user.dto.UserResponse;
import com.bank.user.exception.CustomerNotFoundException;
import com.bank.user.service.UserService;

@ExtendWith(MockitoExtension.class)
public class UserControllerTest {

	private static final String USER_NOT_FOUND_MESSAGE = "User not found";
	private static final int id = 10;
	private static final String USER_NAME_EMPTY_MESSAGE = "User name should not be empty";
	private static final String EMAIL_EMPTY_MESSAGE = "Email should not be empty";
	private static final String AGE_NULL_MESSAGE = "Age should not be null";
	private static final String PHONE_NUMBER_EMPTY_MESSAGE = "Phone number shold not be an empty";
	private static final String PASSWORD_INVALID_MESSAGE = "Password should between 4 to 10 characters";
	private static final String EMAIL_INVALID_MESSAGE = "Email should be in xyz@gmail.com format";
	private static final String AGE_INVALID_MESSAGE = "Minimum age should be 15 for register";
	private static final String PHONE_NUMBER_INVALID_MESSAGE = "Phone number should be 10 digits";

	@Mock
	private UserService userService;

	@InjectMocks
	private UserController userController;
	private Validator validator;

	private UserRequest userRequest;
	private ServiceUserResponse serviceUserResponse;

	@BeforeEach
	void setUp() {
		userRequest = UserRequest.builder().userName("Rohit").email("rt@gmail.com").age(27).phoneNo("9767896543")
				.password("abc789").build();
		serviceUserResponse = new ServiceUserResponse(id, "Rohit", "rt@gmail.com", "7645673456", 27);
		ValidatorFactory validatorFactory = Validation.buildDefaultValidatorFactory();
		validator = validatorFactory.getValidator();

	}

	@Test
	@DisplayName("User register: positive")
	void regiterUserTest() {
		// given
		when(userService.registerUser(any(UserRequestDto.class))).thenReturn(id);
		// when
		ResponseEntity<String> result = userController.registerUser(userRequest);
		// then
		assertEquals("User register successful with Id: " + id, result.getBody());
		assertEquals(HttpStatus.CREATED, result.getStatusCode());
	}

	@Test
	@DisplayName("User register: negative")
	void registerUserTestNegative() {
		when(userService.registerUser(any(UserRequestDto.class))).thenReturn(null);
		ResponseEntity<String> result = userController.registerUser(userRequest);
		assertEquals("Register failed", result.getBody());
		assertEquals(HttpStatus.BAD_REQUEST, result.getStatusCode());
	}

	@Test
	@DisplayName("User deletion: positive")
	void deleteUser() {
		String result = userController.deleteUser(id);
		assertEquals("Deleted successfully", result);
	}

	@Test
	@DisplayName("User deletion: negative")
	void deleteUserNegative() {
		doThrow(new CustomerNotFoundException(USER_NOT_FOUND_MESSAGE)).when(userService).deleteUser(id);
		Exception e = assertThrows(CustomerNotFoundException.class, () -> userService.deleteUser(id));
		assertEquals(USER_NOT_FOUND_MESSAGE, e.getMessage());

	}

	@Test
	@DisplayName("get user: positive")
	void getUserTest() {

		when(userService.getUser(id)).thenReturn(serviceUserResponse);
		UserResponse result = userController.getUser(id);
		assertEquals(id, result.getUserId());
	}

	@Test
	@DisplayName("update user: positive")
	void updateUserTest() {
		String result = userController.updateUser(id, userRequest);
		assertEquals("Updated " + id + " successful", result);
	}

	@Test
	void getAllUsers() {
		when(userService.getAllUsers()).thenReturn(getServiceUserResponses());
		List<UserResponse> userResponses = userController.getAllUsers();
		assertFalse(userResponses.isEmpty());
		assertEquals(userResponses.size(), getServiceUserResponses().size());
		assertEquals("Rohit", userResponses.get(0).getUserName());
	}

	private List<ServiceUserResponse> getServiceUserResponses() {
		ServiceUserResponse serviceUserResponse2 = new ServiceUserResponse(id, "Rakesh", "rk@gmail.com", "7645673456",
				27);
		List<ServiceUserResponse> serviceUserResponses = Arrays.asList(serviceUserResponse, serviceUserResponse2);
		return serviceUserResponses;
	}

//////////////////////////////////////////////////////////
	@Test
	void testInvalidPhoneNumberValidation() {
		userRequest.setPhoneNo("899");
		Set<ConstraintViolation<UserRequest>> violations = validator.validate(userRequest);
		violations.forEach(error -> {
			assertEquals(PHONE_NUMBER_INVALID_MESSAGE, error.getMessage());
		});
	}

	@Test
	void testInvalidEmailValidation() {
		userRequest.setEmail("abc");
		Set<ConstraintViolation<UserRequest>> violations = validator.validate(userRequest);
		violations.forEach(error -> {
			assertEquals(EMAIL_INVALID_MESSAGE, error.getMessage());
		});
	}

	@Test
	void testInvalidAgeValidation() {
		userRequest.setAge(12);
		Set<ConstraintViolation<UserRequest>> violations = validator.validate(userRequest);
		violations.forEach(error -> {
			assertEquals(AGE_INVALID_MESSAGE, error.getMessage());
		});
	}

	@Test
	void testInvalidPasswordValidation() {
		userRequest.setPassword("abc");
		Set<ConstraintViolation<UserRequest>> violations = validator.validate(userRequest);
		violations.forEach(error -> {
			assertEquals(PASSWORD_INVALID_MESSAGE, error.getMessage());
		});
	}

	@Test
	void testEmptyUserNameValidation2() {
		userRequest.setUserName("");
		Set<ConstraintViolation<UserRequest>> violations = validator.validate(userRequest);
		violations.forEach(error -> {
			assertEquals(USER_NAME_EMPTY_MESSAGE, error.getMessage());
			assertFalse(violations.isEmpty());
		});
	}

	@Test
	void testAllValidFieldValidation() {
		Set<ConstraintViolation<UserRequest>> violations = validator.validate(userRequest);
		assertTrue(violations.isEmpty());
	}
}
