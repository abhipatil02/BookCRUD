package com.bank.user.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.crypto.password.PasswordEncoder;

import com.bank.user.dto.ServiceUserResponse;
import com.bank.user.dto.UserRequestDto;
import com.bank.user.dto.UserResponse;
import com.bank.user.entity.User;
import com.bank.user.exception.CustomerNotFoundException;
import com.bank.user.repository.UserRepository;
import com.bank.user.serviceimpl.UserServiceImpl;

@ExtendWith(MockitoExtension.class)
public class UserServiceTest {

	private static final String CUSTOMER_NOT_FOUND_MESSAGE = "Customer not found";
	private static final int id = 10;
	private static final String password = "abcdef";

	@Mock
	private UserRepository userRepo;
	@InjectMocks
	private UserServiceImpl userService;
	@Mock
	private PasswordEncoder encoder;

	UserRequestDto userRequestDto;
	User user;
	Optional<User> returnedUser;
	Optional<User> emptyUser;

	@BeforeEach
	void setUp() {
		userRequestDto = new UserRequestDto("Rohit", "rt@gmail", 27,"8756345634", password);
		user = new User(id, "Rohit", "rt@gmail", 27,"3456786545", "rt123", true);
		returnedUser = Optional.of(user);
		emptyUser = Optional.empty();
		
	}

	@Test
	void registerUser() {
		when(userRepo.save(any(User.class))).thenReturn(user);
		assertEquals(id, userService.registerUser(userRequestDto));
	}

	@Test
	void registerUserNegative() {
		when(userRepo.save(any(User.class))).thenReturn(null);
		assertNull(userService.registerUser(userRequestDto));
	}

	@Test
	@DisplayName("User deletion: positive")
	void deleteUser() {

		when(userRepo.findByUserIdAndIsUserActive(id, true)).thenReturn(returnedUser);
		userService.deleteUser(id);

	}

	@Test
	@DisplayName("User deletion: negative")
	void deleteUserNegative() {

		when(userRepo.findByUserIdAndIsUserActive(id, true)).thenReturn(emptyUser);
		Exception e = assertThrows(CustomerNotFoundException.class, () -> userService.deleteUser(id));
		assertEquals(CUSTOMER_NOT_FOUND_MESSAGE, e.getMessage());

	}

	@Test
	@DisplayName("get user: positive")
	void getUser() {

		when(userRepo.findByUserIdAndIsUserActive(id, true)).thenReturn(returnedUser);
		ServiceUserResponse result = userService.getUser(id);
		assertEquals(id, result.getUserId());

	}
	
	@Test
	void getAllUsers() {
		when(userRepo.findAll()).thenReturn(getListOfUsers());
		List<ServiceUserResponse> serviceUserResponses = userService.getAllUsers();
		assertFalse(serviceUserResponses.isEmpty());
		assertEquals(serviceUserResponses.size(),getListOfUsers().size());	
		assertEquals("Rohit",serviceUserResponses.get(0).getUserName());
	}
	
	private List<User> getListOfUsers(){
		User user2 = new User(id, "Rakesh", "rk@gmail.com", 27,"7645673456","uhdhj",true);
		List<User> users = Arrays.asList(user,user2);
		return users;
	}

}
