package com.bank.user.dto;

public interface UserResponseDto {
	
	public Integer getUserId();
	public String getUserName();
	public String getEmail();
	public int getAge();

}
