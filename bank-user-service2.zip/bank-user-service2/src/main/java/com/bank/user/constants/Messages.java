package com.bank.user.constants;

public final class Messages {

	private Messages() {

	}

	public static final String USER_NAME_EMPTY_MESSAGE = "User name should not be empty";
	public static final String EMAIL_EMPTY_MESSAGE = "Email should not be empty";
	public static final String AGE_NULL_MESSAGE = "Age should not be null";
	public static final String PHONE_NUMBER_EMPTY_MESSAGE = "Phone number shold not be an empty";
	public static final String PASSWORD_INVALID_MESSAGE = "Password should between 4 to 10 characters";
	public static final String EMAIL_INVALID_MESSAGE = "Email should be in xyz@gmail.com format";
	public static final String AGE_INVALID_MESSAGE = "Minimum age should be 15 for register";
	public static final String PHONE_NUMBER_INVALID_MESSAGE = "Phone number should be 10 digits";
}
