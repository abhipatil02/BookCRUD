package com.bank.user.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class UserRequestDto {

	private String userName;
	private String email;
	private int age;
	private String phoneNo;
	private String password;

}
