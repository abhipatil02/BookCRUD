package com.bank.user.dto;

import lombok.Data;

@Data
public class UserResponse {
	private Integer userId;
	private String userName;
	private String email;
	private String phoneNo;
	private int age;

}
