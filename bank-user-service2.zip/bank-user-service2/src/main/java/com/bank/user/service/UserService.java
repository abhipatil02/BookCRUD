package com.bank.user.service;

import java.util.List;

import com.bank.user.dto.ServiceUserResponse;
import com.bank.user.dto.UserRequestDto;
import com.bank.user.dto.UserResponseDto;
import com.bank.user.entity.User;

public interface UserService {
	

	public Integer registerUser(UserRequestDto userRequestDto);

	public void deleteUser(Integer id);

	public void updateUser(Integer id, UserRequestDto userRequestDto);

	public ServiceUserResponse getUser(Integer id);

	public List<ServiceUserResponse> getAllUsers();

}
