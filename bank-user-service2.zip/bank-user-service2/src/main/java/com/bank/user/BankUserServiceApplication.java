package com.bank.user;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BankUserServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(BankUserServiceApplication.class, args);
	}

}
