package com.bank.user.exception;

import java.time.LocalDateTime;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;

@RestControllerAdvice
public class GlobalExceptionHandler {

	private static Logger logger = LoggerFactory.getLogger(GlobalExceptionHandler.class);

	private ErrorResponse getErrorResponse(String message, int statusCode) {
		var errorResponse = new ErrorResponse();
		errorResponse.setDateTime(LocalDateTime.now());
		errorResponse.setMessage(message);
		errorResponse.setStatusCode(statusCode);

		return errorResponse;

	}

	@ExceptionHandler(CustomerNotFoundException.class)
	public ResponseEntity<ErrorResponse> handerException(CustomerNotFoundException e) {

		logger.error("CustomerNotFoundException occured");
		return new ResponseEntity<>(getErrorResponse(e.getMessage(), HttpStatus.NOT_FOUND.value()),
				HttpStatus.NOT_FOUND);
	}

	@ExceptionHandler(MethodArgumentNotValidException.class)
	public ResponseEntity<ValidationErrorResponse> handerException(MethodArgumentNotValidException e) {
		logger.error("MethodArgumentNotValidException occured");
		List<FieldError> fieldErrors = e.getFieldErrors();
		var validationErrorResponse = new ValidationErrorResponse();

		validationErrorResponse.setMessage("Invalid input");
		validationErrorResponse.setStatusCode(HttpStatus.BAD_REQUEST.value());
		validationErrorResponse.setDateTime(LocalDateTime.now());

		fieldErrors.stream()
				.forEach(error -> validationErrorResponse.getErrors().put(error.getField(), error.getDefaultMessage()));

		return new ResponseEntity<>(validationErrorResponse, HttpStatus.BAD_REQUEST);

	}

}
