package com.bank.user.dto;

import static com.bank.user.constants.Messages.*;

import javax.validation.constraints.Email;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import lombok.Builder;
import lombok.Data;

@Builder
@Data
public class UserRequest {

	@NotEmpty(message = USER_NAME_EMPTY_MESSAGE)
	private String userName;

	//@NotEmpty(message = EMAIL_EMPTY_MESSAGE)
	@Email(message = EMAIL_INVALID_MESSAGE, regexp = "[a-zA-Z]+[a-zA-Z0-9-]*@[a-z]{2,8}+\\.[a-z]+")
	private String email;

	@NotNull(message = AGE_NULL_MESSAGE)
	@Min(value = 15, message = AGE_INVALID_MESSAGE)
	private int age;

	//@NotEmpty(message = PHONE_NUMBER_EMPTY_MESSAGE)
	@Pattern(message = PHONE_NUMBER_INVALID_MESSAGE, regexp = "[0-9]{10}")
	private String phoneNo;

	@Size(min = 4, max = 10, message = PASSWORD_INVALID_MESSAGE)
	private String password;

}
