package com.bank.user.controller;

import java.util.List;
import java.util.stream.Collector;
import java.util.stream.Collectors;

import javax.validation.Valid;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.bank.user.dto.ServiceUserResponse;
import com.bank.user.dto.UserRequest;
import com.bank.user.dto.UserRequestDto;
import com.bank.user.dto.UserResponse;
import com.bank.user.service.UserService;

import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/users")
@Slf4j
public class UserController {

	@Autowired
	private UserService userService;

	@PostMapping("/register")
	public ResponseEntity<String> registerUser(@Valid @RequestBody UserRequest userRequest) {
		UserRequestDto userRequestDto = new UserRequestDto();
		BeanUtils.copyProperties(userRequest, userRequestDto);
		Integer id = userService.registerUser(userRequestDto);
		if (id != null) {
			log.info("User registered successful with id " + id);

			return new ResponseEntity<String>("User register successful with Id: " + id, HttpStatus.CREATED);
		}
		return new ResponseEntity<String>("Register failed", HttpStatus.BAD_REQUEST);

	}

	@GetMapping("/{id}")
	@ResponseStatus(HttpStatus.FOUND)
	public UserResponse getUser(@PathVariable("id") Integer id) {
		UserResponse userResponse = new UserResponse();
		BeanUtils.copyProperties(userService.getUser(id), userResponse);
		log.info("User {} retrieved data", id);
		return userResponse;

	}

	@DeleteMapping("/{id}")
	@ResponseStatus(HttpStatus.OK)
	public String deleteUser(@PathVariable("id") Integer id) {
		userService.deleteUser(id);
		log.info("User {} deleted", id);
		return "Deleted successfully";
	}

	@PutMapping("/{id}")
	@ResponseStatus(HttpStatus.CREATED)
	public String updateUser(@PathVariable("id") Integer id, @Valid @RequestBody UserRequest userRequest) {
		UserRequestDto userRequestDto = new UserRequestDto();
		BeanUtils.copyProperties(userRequest, userRequestDto);

		userService.updateUser(id, userRequestDto);
		log.info("User {} updated data", id);
		return "Updated " + id + " successful";
	}

	@GetMapping("/all-users")
	@ResponseStatus(HttpStatus.OK)
	public List<UserResponse> getAllUsers() {
		List<ServiceUserResponse> serviceUserResponses = userService.getAllUsers();
		log.info(serviceUserResponses.toString());
		List<UserResponse> userResponses = serviceUserResponses.stream().map(serviceUserResponse -> {
			UserResponse userResponse = new UserResponse();
			BeanUtils.copyProperties(serviceUserResponse, userResponse);
			log.info("Inside "+userResponse.toString());

			return userResponse;
		}).collect(Collectors.toList());
		log.info(userResponses.toString());
		

		return userResponses;
	}

}
