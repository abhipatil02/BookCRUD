package com.bank.user.serviceimpl;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.bank.user.dto.ServiceUserResponse;
import com.bank.user.dto.UserRequestDto;
import com.bank.user.dto.UserResponseDto;
import com.bank.user.entity.User;
import com.bank.user.exception.CustomerNotFoundException;
import com.bank.user.repository.UserRepository;
import com.bank.user.service.UserService;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	private UserRepository userRepo;
	@Autowired
	private PasswordEncoder encoder;

	@Override
	public Integer registerUser(UserRequestDto userRequestDto) {

		User user = new User();
		BeanUtils.copyProperties(userRequestDto, user);
		user.setPassword(encoder.encode(userRequestDto.getPassword()));
		user.setIsUserActive(true);
		User savedUser = userRepo.save(user);
		if (savedUser == null)
			return null;

		return savedUser.getUserId();
	}

	@Override
	public void deleteUser(Integer id) {
		User user = userRepo.findByUserIdAndIsUserActive(id, true)
				.orElseThrow(() -> new CustomerNotFoundException("Customer not found"));
		user.setIsUserActive(false);
		userRepo.save(user);

	}

	@Override
	public void updateUser(Integer id, UserRequestDto userRequestDto) {
		User user = userRepo.findByUserIdAndIsUserActive(id, true)
				.orElseThrow(() -> new CustomerNotFoundException("Customer not found"));
		BeanUtils.copyProperties(userRequestDto, user);
		user.setPassword(encoder.encode(userRequestDto.getPassword()));
		userRepo.save(user);

	}

	@Override
	public ServiceUserResponse getUser(Integer id) {

		User user = userRepo.findByUserIdAndIsUserActive(id, true)
				.orElseThrow(() -> new CustomerNotFoundException("Customer not found"));
		ServiceUserResponse userResponse = new ServiceUserResponse();
		BeanUtils.copyProperties(user, userResponse);
		return userResponse;
	}

	@Override
	public List<ServiceUserResponse> getAllUsers() {
		List<User> users = userRepo.findAll();
		List<ServiceUserResponse> serviceUserResponses = users.stream().map(user -> {
			ServiceUserResponse serviceUserResponse = new ServiceUserResponse();
			BeanUtils.copyProperties(user, serviceUserResponse);
			return serviceUserResponse;
		}).collect(Collectors.toList());

		return serviceUserResponses;

	}

}
